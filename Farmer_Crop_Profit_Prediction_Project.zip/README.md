# Farmer Crop Profit Prediction System

A complete Data Science + Machine Learning project that predicts crop profit using historical agriculture data.

## Project contents
- `data/farmer_crop_profit_dataset.csv` - 5,000-row dataset
- `data/farmer_crop_profit_dataset.xlsx` - Excel version
- `models/profit_prediction_model.joblib` - trained best model
- `models/model_metrics.csv` - model comparison
- `app/app.py` - Streamlit dashboard
- `app/requirements.txt` - Python dependencies
- `report/Farmer_Crop_Profit_Prediction_Report.docx` - project report
- `ppt/Farmer_Crop_Profit_Prediction_Presentation.pptx` - presentation

## How to run
1. Install Python 3.10+.
2. Open a terminal in this project folder.
3. Install dependencies:
   `pip install -r app/requirements.txt`
4. Run:
   `streamlit run app/app.py`

## ML target
`Profit_INR`

## Models compared
- Linear Regression
- Random Forest Regressor

The best model by R² is saved as `models/profit_prediction_model.joblib`.

## Important
The included dataset is synthetic and intended for academic/demo use. Replace it with verified local agricultural, cost, yield and market-price data for real-world deployment.
